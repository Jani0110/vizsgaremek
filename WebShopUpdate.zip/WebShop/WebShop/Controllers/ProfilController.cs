using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using WebShop.Models;

public class AccountController : Controller
{
    private readonly UserManager<User> _felhasznaloManager;
    private readonly SignInManager<User> _bejelentkezesManager;

    public AccountController(UserManager<User> userManager, SignInManager<User> signInManager)
    {
        _felhasznaloManager= userManager;
        _bejelentkezesManager = signInManager;
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(UserRegistrationViewModel model)
    {
        if (ModelState.IsValid)
        {
            var user = new User { FelhasznaloNev = model.FelhasznaloNev, Email = model.Email, Jelszo= model.Jelszo };
            var result = await _felhasznaloManager.CreateAsync(user, model.Jelszo);

            if (result.Succeeded)
            {
                // You may optionally sign in the user here or redirect to the login page.
                // For example:
                // await _signInManager.SignInAsync(user, isPersistent: false);
            }
            else
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
        }

        return View(model);
    }
}

public class UserRegistrationViewModel
{
    [Required]
    [StringLength(100, ErrorMessage = "The {0} must be at least {2} and at most {1} characters long.", MinimumLength = 6)]
    public required string FelhasznaloNev { get; set; }

    [Required]
    [EmailAddress]
    public required string Email { get; set; }

    [Required]
    [DataType(DataType.Password)]
    [StringLength(100, ErrorMessage = "The {0} must be at least {2} and at most {1} characters long.", MinimumLength = 6)]
    public required string Jelszo { get; set; }

    [DataType(DataType.Password)]
    [Compare("Password", ErrorMessage = "Nem megfelel� jelsz�")]
    public required string ConfirmPassword { get; set; }
}