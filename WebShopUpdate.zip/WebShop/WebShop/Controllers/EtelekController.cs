﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using MyNamespace;

namespace chineseBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EtelekController : ControllerBase
    {
        private readonly WebshopDbContext _context;

        public EtelekController(WebshopDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Etel>> GetEtelek()
        {
            return _context.Etelek.ToList();
        }

        [HttpGet("{id}")]
        public ActionResult<Etel> GetEtel(int id)
        {
            var etel = _context.Etelek.Find(id);

            if (etel == null)
            {
                return NotFound();
            }

            return etel;
        }

        [HttpPost]
        public ActionResult<Etel> PostEtel(Etel etel)
        {
            _context.Etelek.Add(etel);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetEtel), new { id = etel.Id }, etel);
        }

        [HttpPut("{id}")]
        public IActionResult PutEtel(int id, Etel etel)
        {
            if (id != etel.Id)
            {
                return BadRequest();
            }

            _context.Entry(etel).State = EntityState.Modified;
            _context.SaveChanges();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEtel(int id)
        {
            var etel = _context.Etelek.Find(id);

            if (etel == null)
            {
                return NotFound();
            }

            _context.Etelek.Remove(etel);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
