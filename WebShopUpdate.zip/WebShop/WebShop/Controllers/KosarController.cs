﻿using System.Collections.Generic;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;
using RouteAttribute = System.Web.Http.RouteAttribute;

public class KosarController : ApiController
{
    private readonly KosarController kosar;

    public KosarController()
    {
        kosar = new Kosar();
    }

    [System.Web.Http.HttpPost]
    [System.Web.Http.Route("api/kosar/addfood")]
    public IHttpActionResult AddSelectedFood(int foodID, string? foodName, [System.Web.Http.FromBody] ValasztottEtelModel valasztott)
    {
        if (valasztott == null)
        {
            return BadRequest("A kosár üres");
        }

        kosar.AddSelectedFood(valasztott.FoodID, valasztott.FoodName);

        return Ok("Termék hozzáadva");
    }

    private void AddSelectedFood(int foodID, string? foodName)
    {
        throw new NotImplementedException();
    }

    [Microsoft.AspNetCore.Mvc.HttpGet]
    [Route("api/kosar/getfoods")]
    public IHttpActionResult GetSelectedFoods()
    {
        List<Tuple<int, string, int>> valasztott = (List<Tuple<int, string, int>>)kosar.GetSelectedFoods();

        return Ok(valasztott);
    }
}

internal class Kosar : KosarController
{
}

public class ValasztottEtelModel
{
    public int FoodID { get; set; }
    public string? FoodName { get; set; }
    public int Quantity { get; set; }
}
