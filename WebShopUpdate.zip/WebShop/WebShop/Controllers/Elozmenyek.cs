﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;



namespace chineseBackend.Modells
{
    public class SearchHistoryController : ControllerBase
    {
        private readonly SearchHistoryService _searchHistoryService;

        public SearchHistoryController(SearchHistoryService searchHistoryService)
        {
            _searchHistoryService = searchHistoryService;
        }

        [HttpGet("api/search-history")]
        public IActionResult GetSearchHistory()
        {
            List<string> searchHistory = _searchHistoryService.GetSearchHistory();
            return Ok(searchHistory);
        }

        [HttpPost("api/search-history")]
        public IActionResult AddToSearchHistory(string searchTerm)
        {
            _searchHistoryService.AddToSearchHistory(searchTerm);
            return Ok();
        }
    }
    public class SearchHistoryService
    {
        private List<string> _searchHistory;

        public SearchHistoryService()
        {
            _searchHistory = new List<string>();
        }

        public List<string> GetSearchHistory()
        {
            return _searchHistory;
        }

        public void AddToSearchHistory(string searchTerm)
        {
            _searchHistory.Add(searchTerm);
        }
    }
}