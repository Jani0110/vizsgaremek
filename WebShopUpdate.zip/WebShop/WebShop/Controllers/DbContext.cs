﻿using Microsoft.EntityFrameworkCore;


namespace MyNamespace
{


public class WebshopDbContext : DbContext
{
    public WebshopDbContext(DbContextOptions<WebshopDbContext> options) : base(options)
    {
    }

    public DbSet<Etel> Etelek { get; set; }
}
}
