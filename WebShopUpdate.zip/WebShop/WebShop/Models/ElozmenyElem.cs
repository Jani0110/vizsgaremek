﻿namespace WebShop.Models
{
    public class ElozmenyElem
    {
        public int Id { get; set; }
        public required string Nev { get; set; }

        public DateTime KeresesIdeje { get; set; }
    }
}
