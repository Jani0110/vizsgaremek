﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MyNamespace
{
    public class KosarElem
    {
        [Key]
        public string? KosarItemId { get; set; }

        [Required]
        public string? KosarId { get; set; }
        public int id { get; set; }
        public int szam { get; set; }
        public string? felhasznaloId { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime KeszDatum { get; set; }

        public virtual required Etel Etel { get; set; }
    }
}

