﻿namespace chineseBackend.Dto
{
    public record CreateFood(int id, string nev, string meret, string leiras, int ar);
}