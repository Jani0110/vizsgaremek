﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace vizsgaWpf
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        public object password { get; private set; }

        public Register(string? Username, string? password)
        {
            InitializeComponent();
        }

        private void RegisterBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Server=localhost;Database=vizsgarework sslmode=none");
                con.Open();
                string hozzaad = "INSERT INTO[felhasznalonev,jelszo] VALUES(@felhasznalonev, @jelszo)";
                SqlCommand cmd = new SqlCommand(hozzaad,con);



                cmd.Parameters.AddWithValue("@felhasznalonev", Username.Text);
                cmd.Parameters.AddWithValue("@jelszo", Password.Password);
                cmd.ExecuteNonQuery();
                con.Close();

                Username.Text = "";
                password = "";
                MainWindow w1 = new();
                this.Close();
                w1.Show();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void LoginBtn_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Server=localhost;Database=vizsgarework sslmode=none");
            con.Open();
            string hozzaad = "INSERT INTO[felhasznalonev,jelszo] VALUES(@felhasznalonev, @jelszo)";
            SqlCommand cmd = new SqlCommand(hozzaad, con);



            cmd.Parameters.AddWithValue("@felhasznalonev", Username.Text);
            cmd.Parameters.AddWithValue("@jelszo", Password.Password);
            cmd.ExecuteNonQuery();
            int count = Convert.ToInt32(((SqlCommand)cmd).ExecuteScalar());
            con.Close();

            Username.Text = "";
            password = "";

            if (count > 0) 
            {
                Dosomething d1= new Dosomething();
                this.Close();
                d1.Show();
            }
            else
            {
                MessageBox.Show("hibás felhasználónév vagy jelszó");
            }

            MainWindow w1 = new();
            this.Close();
            w1.Show();
        }

        private class Dosomething
        {
        }
    }
}
