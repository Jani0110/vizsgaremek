﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VizsgaremekAPI.Dtos;
using VizsgaremekAPI.Models;

namespace VizsgaremekAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class EtelekController : ControllerBase
    {
        [HttpGet("getall")]
        public ActionResult<IEnumerable<Etelek>> GetAll()
        {
            try
            {
                using(var dbContext = new VizsgareworkContext())
                {
                    var result = dbContext.Eteleks.ToList();
                    return Ok(result);
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("createEtel")]
        public ActionResult PostEtel(CreateEtel createEtel)
        {
            try
            {
                using(var dbContext = new VizsgareworkContext())
                {
                    var newEtel = new Etelek()
                    {
                        Nev = createEtel.Nev,
                        Ar = createEtel.Ar,
                        Meret = createEtel.Meret,
                        KategoriaId = createEtel.Kategoria_Id,
                        Leiras = createEtel.Leiras,
                    };

                    dbContext.Eteleks.Add(newEtel);
                    dbContext.SaveChanges();

                    return Ok("Sikeres hozzáadás");
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("updateEtel")]
        public ActionResult UpdateEtel(UpdateEtel updateEtel)
        {
            try
            {
                using (var dbContext = new VizsgareworkContext())
                {
                    var existing = dbContext.Eteleks.FirstOrDefault(x => x.Id == updateEtel.Id);
                    if (existing != null)
                    {
                        existing.Nev = updateEtel.Nev;
                        existing.Ar = updateEtel.Ar;
                        existing.Meret  = updateEtel.Meret;
                        existing.KategoriaId = updateEtel.Kategoria_Id;
                        existing.Leiras = updateEtel.Leiras;

                        dbContext.Eteleks.Update(existing);
                        dbContext.SaveChanges();

                        return Ok("Sikeres módosítás");
                    }
                    else
                    {
                        return NotFound("Nem található a módosítani kívánt étel");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("deleteEtel/{id}")]
        public ActionResult deleteEtel(int id)
        {
            try
            {
                using(var dbContext = new VizsgareworkContext())
                {
                    var existing = dbContext.Eteleks.FirstOrDefault(x => x.Id == id);
                    if (existing != null)
                    {
                        dbContext.Eteleks.Remove(existing);
                        dbContext.SaveChanges();
                        
                        return Ok("Sikeres törlés");
                    }
                    else
                    {
                        return NotFound("Nem található a módosítani kívánt étel");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
