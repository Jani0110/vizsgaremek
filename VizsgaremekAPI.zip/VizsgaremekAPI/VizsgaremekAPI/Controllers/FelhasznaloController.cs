﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.InteropServices;
using VizsgaremekAPI.Dtos;
using VizsgaremekAPI.Models;

namespace VizsgaremekAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class FelhasznaloController : ControllerBase
    {
        [HttpPost("register")]
        public ActionResult Register(RegisterDto registerDto)
        {
            try
            {
                using(var dbContext = new VizsgareworkContext())
                {
                    var newVevo = new Vevok()
                    {
                        Email = registerDto.Email,
                        Vezeteknev = registerDto.Vezeteknev,
                        Keresztnev = registerDto.Keresztnev,
                        Jelszo = registerDto.Jelszo,
                        Felhasznalonev = registerDto.Felhasznalonev,
                        Telszam = registerDto.Telszam,
                    };

                    dbContext.Vevoks.Add(newVevo);
                    dbContext.SaveChanges();

                    return Ok(newVevo);
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("login")]
        public ActionResult Login(LoginDto loginDto)
        {
            try
            {
                using(var dbContext = new VizsgareworkContext())
                {
                    var existing = dbContext.Vevoks.FirstOrDefault(x => x.Email == loginDto.Email);
                    if (existing != null)
                    {
                        if (existing.Jelszo == loginDto.Jelszo)
                        {
                            return Ok("Sikeres bejelentkezés");
                        }
                        else
                        {
                            return NotFound("Hibás email cím vagy jelszó");
                        }
                    }
                    else
                    {
                        return NotFound("Hibás email cím vagy jelszó");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
