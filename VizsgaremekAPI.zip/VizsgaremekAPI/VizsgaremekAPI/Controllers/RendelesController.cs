﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VizsgaremekAPI.Dtos;
using VizsgaremekAPI.Models;

namespace VizsgaremekAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class RendelesController : ControllerBase
    {
        [HttpGet("getAllRendeles")]
        public ActionResult<IEnumerable<RendelesTeljes>> GetAll()
        {
            try
            {
                using(var dbContext = new VizsgareworkContext())
                {
                    List<RendelesTeljes> result = new List<RendelesTeljes>();

                    var rendelesek = dbContext.Rendeleseks.Include(x => x.Vevo).ToList();
                    foreach (var item in rendelesek)
                    {
                        List<RendeltEtel> rendeltetelek = dbContext.RendeltEtels.Where(x => x.RendelesId == item.Id).Include(x => x.Etel).ToList();

                        RendelesTeljes rendeles = new RendelesTeljes(item.Id, item.Vevo.Vezeteknev + item.Vevo.Keresztnev, item.RendelesDatuma.ToString(), item.Vegosszeg, rendeltetelek);
                        result.Add(rendeles);

                    }

                    return Ok(result);
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getbyid/{id}")]
        public ActionResult<RendelesTeljes> GetById(int id)
        {
            try
            {
                using (var dbContext = new VizsgareworkContext())
                {
                    var rendeles = dbContext.Rendeleseks.Include(x => x.Vevo).FirstOrDefault(x => x.Id == id);

                    if (rendeles == null)
                    {
                        List<RendeltEtel> rendeltetelek = dbContext.RendeltEtels.Where(x => x.RendelesId == rendeles.Id).Include(x => x.Etel).ToList();
                        var result = new RendelesTeljes(rendeles.Id, rendeles.Vevo.Vezeteknev + rendeles.Vevo.Keresztnev, rendeles.RendelesDatuma.ToString(),rendeles.Vegosszeg, rendeltetelek);

                        return Ok(result);
                    }
                    else
                    {
                        return NotFound("Nincs rendelés ilyen id-vel");
                    }
                    
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("createRendeles")]
        public ActionResult PostRendeles(CreateRendeles createRendeles)
        {
            try
            {
                using(var dbContext = new VizsgareworkContext())
                {
                    int vegosszeg = 0;

                    var newRendeles = new Rendelesek()
                    {
                        Id = dbContext.Rendeleseks.Last().Id,
                        VevoId = createRendeles.vevo_Id,
                        RendelesDatuma = DateTime.Now,
                        Vegosszeg = vegosszeg

                    };
                    dbContext.Rendeleseks.Add(newRendeles);

                    foreach (var item in createRendeles.RendeltTermeks)
                    {
                        var newRendeltEtel = new RendeltEtel()
                        {
                            RendelesId = newRendeles.Id,
                            EtelId = item.Id,
                            Mennyiseg = item.Mennyiseg,
                        };

                        var etel = dbContext.Eteleks.FirstOrDefault(x => x.Id == newRendeltEtel.Id);
                        vegosszeg += etel.Ar;

                        dbContext.RendeltEtels.Add(newRendeltEtel);
                    }

                    dbContext.Rendeleseks.Update(newRendeles);
                    dbContext.SaveChanges();

                    return Ok("Sikeres rendelés");
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
