﻿using System;
using System.Collections.Generic;

namespace VizsgaremekAPI.Models;

public partial class Vevok
{
    public int Id { get; set; }

    public string Vezeteknev { get; set; } = null!;

    public string Keresztnev { get; set; } = null!;

    public string Felhasznalonev { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Jelszo { get; set; } = null!;

    public int Telszam { get; set; }

    public virtual ICollection<Rendelesek> Rendeleseks { get; set; } = new List<Rendelesek>();
}
