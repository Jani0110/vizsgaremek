﻿using System;
using System.Collections.Generic;

namespace VizsgaremekAPI.Models;

public partial class Kategoriak
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public virtual ICollection<Etelek> Eteleks { get; set; } = new List<Etelek>();
}
