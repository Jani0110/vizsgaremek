﻿using System;
using System.Collections.Generic;

namespace VizsgaremekAPI.Models;

public partial class RendeltEtel
{
    public int Id { get; set; }

    public int RendelesId { get; set; }

    public int EtelId { get; set; }

    public int Mennyiseg { get; set; }

    public virtual Etelek Etel { get; set; } = null!;

    public virtual Rendelesek Rendeles { get; set; } = null!;
}
