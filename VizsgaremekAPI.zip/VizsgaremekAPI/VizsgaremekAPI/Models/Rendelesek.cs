﻿using System;
using System.Collections.Generic;

namespace VizsgaremekAPI.Models;

public partial class Rendelesek
{
    public int Id { get; set; }

    public int VevoId { get; set; }

    public DateTime RendelesDatuma { get; set; }

    public int Vegosszeg { get; set; }

    public virtual ICollection<RendeltEtel> RendeltEtels { get; set; } = new List<RendeltEtel>();

    public virtual Vevok Vevo { get; set; } = null!;
}
