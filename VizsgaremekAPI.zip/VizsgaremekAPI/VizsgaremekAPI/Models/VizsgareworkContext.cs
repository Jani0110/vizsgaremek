﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace VizsgaremekAPI.Models;

public partial class VizsgareworkContext : DbContext
{
    public VizsgareworkContext()
    {
    }

    public VizsgareworkContext(DbContextOptions<VizsgareworkContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Etelek> Eteleks { get; set; }

    public virtual DbSet<Kategoriak> Kategoriaks { get; set; }

    public virtual DbSet<Rendelesek> Rendeleseks { get; set; }

    public virtual DbSet<RendeltEtel> RendeltEtels { get; set; }

    public virtual DbSet<Vevok> Vevoks { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySQL("SERVER=192.168.1.133;PORT=3306;DATABASE=vizsgarework;USER=root;PASSWORD=password;SSL MODE=none;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Etelek>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("etelek");

            entity.HasIndex(e => e.KategoriaId, "kategoria_id");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Ar).HasColumnName("ar");
            entity.Property(e => e.KategoriaId).HasColumnName("kategoria_id");
            entity.Property(e => e.Leiras)
                .HasMaxLength(255)
                .HasColumnName("leiras");
            entity.Property(e => e.Meret)
                .HasMaxLength(255)
                .HasColumnName("meret");
            entity.Property(e => e.Nev)
                .HasMaxLength(255)
                .HasColumnName("nev");

            entity.HasOne(d => d.Kategoria).WithMany(p => p.Eteleks)
                .HasForeignKey(d => d.KategoriaId)
                .HasConstraintName("etelek_ibfk_1");
        });

        modelBuilder.Entity<Kategoriak>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("kategoriak");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Nev)
                .HasMaxLength(50)
                .HasColumnName("nev");
        });

        modelBuilder.Entity<Rendelesek>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("rendelesek");

            entity.HasIndex(e => e.VevoId, "vevo_id");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.RendelesDatuma)
                .HasColumnType("date")
                .HasColumnName("rendeles_datuma");
            entity.Property(e => e.Vegosszeg).HasColumnName("vegosszeg");
            entity.Property(e => e.VevoId).HasColumnName("vevo_id");

            entity.HasOne(d => d.Vevo).WithMany(p => p.Rendeleseks)
                .HasForeignKey(d => d.VevoId)
                .HasConstraintName("rendelesek_ibfk_1");
        });

        modelBuilder.Entity<RendeltEtel>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("rendelt_etel");

            entity.HasIndex(e => e.EtelId, "etel_id");

            entity.HasIndex(e => e.RendelesId, "rendeles_id");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.EtelId).HasColumnName("etel_id");
            entity.Property(e => e.Mennyiseg).HasColumnName("mennyiseg");
            entity.Property(e => e.RendelesId).HasColumnName("rendeles_id");

            entity.HasOne(d => d.Etel).WithMany(p => p.RendeltEtels)
                .HasForeignKey(d => d.EtelId)
                .HasConstraintName("rendelt_etel_ibfk_1");

            entity.HasOne(d => d.Rendeles).WithMany(p => p.RendeltEtels)
                .HasForeignKey(d => d.RendelesId)
                .HasConstraintName("rendelt_etel_ibfk_2");
        });

        modelBuilder.Entity<Vevok>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("vevok");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Email)
                .HasMaxLength(200)
                .HasColumnName("email");
            entity.Property(e => e.Felhasznalonev)
                .HasMaxLength(100)
                .HasColumnName("felhasznalonev");
            entity.Property(e => e.Jelszo)
                .HasMaxLength(32)
                .HasColumnName("jelszo");
            entity.Property(e => e.Keresztnev)
                .HasMaxLength(100)
                .HasColumnName("keresztnev");
            entity.Property(e => e.Telszam).HasColumnName("telszam");
            entity.Property(e => e.Vezeteknev)
                .HasMaxLength(50)
                .HasColumnName("vezeteknev");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
