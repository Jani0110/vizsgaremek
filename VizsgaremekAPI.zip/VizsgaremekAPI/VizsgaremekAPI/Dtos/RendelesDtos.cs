﻿using VizsgaremekAPI.Models;

namespace VizsgaremekAPI.Dtos
{
    public record RendelesTeljes(int Id, string VevoNev, string Datum, int Vegosszeg, List<RendeltEtel> RendeltEtels);
    public record RendeltTermek(int Id, int Mennyiseg);
    public record CreateRendeles(int vevo_Id, List<RendeltTermek> RendeltTermeks);
}
