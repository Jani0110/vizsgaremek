﻿namespace VizsgaremekAPI.Dtos
{
    public record CreateEtel(string Nev, int Ar, string Meret, int Kategoria_Id, string Leiras);
    public record UpdateEtel(int Id, string Nev, int Ar, string Meret, int Kategoria_Id, string Leiras);
}
