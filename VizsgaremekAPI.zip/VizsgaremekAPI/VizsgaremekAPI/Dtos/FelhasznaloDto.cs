﻿namespace VizsgaremekAPI.Dtos
{
    public record RegisterDto(string Email, string Keresztnev, string Vezeteknev, string Felhasznalonev, string Jelszo, int Telszam);

    public record LoginDto(string Email, string Jelszo);
}
