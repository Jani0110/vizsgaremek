﻿using System;
using System.Collections.Generic;

namespace backend.Models;

public partial class Etelek
{
    public Guid Id { get; set; }

    public string Nev { get; set; } = null!;

    public int Ar { get; set; }

    public string Meret { get; set; } = null!;

    public Guid KategoriaId { get; set; }

    public string Leiras { get; set; } = null!;

    public virtual Kategoriak Kategoria { get; set; } = null!;

    public virtual ICollection<RendeltEtel> RendeltEtelek { get; set; } = new List<RendeltEtel>();
}
