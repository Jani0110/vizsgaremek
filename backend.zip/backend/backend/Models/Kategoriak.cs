﻿using System;
using System.Collections.Generic;

namespace backend.Models;

public partial class Kategoriak
{
    public Guid Id { get; set; }

    public string Nev { get; set; } = null!;

    public virtual ICollection<Etelek> Etelek { get; set; } = new List<Etelek>();
}
