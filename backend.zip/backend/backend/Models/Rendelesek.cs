﻿using System;
using System.Collections.Generic;

namespace backend.Models;

public partial class Rendelesek
{
    public Guid Id { get; set; }

    public Guid VevoId { get; set; }

    public DateTime RendelesDatuma { get; set; }

    public int Vegosszeg { get; set; }

    public virtual ICollection<RendeltEtel> RendeltEtelek { get; set; } = new List<RendeltEtel>();

    public virtual Vevok Vevo { get; set; } = null!;
}
