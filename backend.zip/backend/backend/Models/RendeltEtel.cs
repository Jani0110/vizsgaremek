﻿using System;
using System.Collections.Generic;

namespace backend.Models;

public partial class RendeltEtel
{
    public Guid Id { get; set; }

    public Guid RendelesId { get; set; }

    public Guid EtelId { get; set; }

    public int Mennyiseg { get; set; }

    public virtual Etelek Etel { get; set; } = null!;

    public virtual Rendelesek Rendeles { get; set; } = null!;
}
