﻿using backend.Models;
using Microsoft.AspNetCore.Mvc;

namespace backend.Controllers
{
    public class VevoController : Controller
    {   
    [Route("api/[controller]")]
        [ApiController]
        public class VevokController : ControllerBase
        {
            private readonly VizsgareworkContext _context;

            public VevokController(VizsgareworkContext context)
            {
                _context = context;
            }

            // GET: api/Vevok
            [HttpGet]
            public ActionResult<IEnumerable<Vevok>> GetVevoks()
            {
                return _context.Vevok.ToList();
            }

            // GET: api/Vevok/5
            [HttpGet("{id}")]
            public ActionResult<Vevok> GetVevok(int id)
            {
                var vevok = _context.Vevok.Find(id);

                if (vevok == null)
                {
                    return NotFound();
                }

                return vevok;
            }

            // PUT: api/Vevok/5
            [HttpPut("{id}")]
            public IActionResult PutVevok(int id, Vevok vevok)
            {
                if (id != vevok.Id)
                {
                    return BadRequest();
                }

                _context.Entry(vevok).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

                try
                {
                    _context.SaveChanges();
                }
                catch (Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException)
                {
                    if (!VevokExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return NoContent();
            }

            // POST: api/Vevok
            [HttpPost]
            public ActionResult<Vevok> PostVevok(Vevok vevok)
            {
                _context.Vevok.Add(vevok);
                _context.SaveChanges();

                return CreatedAtAction("GetVevok", new { id = vevok.Id }, vevok);
            }

            // DELETE: api/Vevok/5
            [HttpDelete("{id}")]
            public IActionResult DeleteVevok(int id)
            {
                var vevok = _context.Vevok.Find(id);
                if (vevok == null)
                {
                    return NotFound();
                }

                _context.Vevoks.Remove(vevok);
                _context.SaveChanges();

                return NoContent();
            }

            private bool VevokExists(int id)
            {
                return _context.Vevok.Any(e => e.Id == id);
            }
        }
    }
}

