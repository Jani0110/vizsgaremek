﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]


    public class RendeltController : ControllerBase
    {
        public class VevokController : ControllerBase
        {
            private readonly VizsgareworkContext _context;

            public VevokController(VizsgareworkContext context)
            {
                _context = context;
            }

            // GET: api/Rendelt
            [HttpGet]
        public IActionResult Get()
        {
            // Logika megvalósítása az összes rendelt tétel lekérdezéséhez
            return Ok("Az összes rendelt tétel lekérdezése");
        }

        // GET: api/Rendelt/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            // Logika megvalósítása egy adott rendelt tétel lekérdezéséhez az azonosító alapján
            return Ok($"Rendelt tétel lekérdezése azonosító alapján: {id}");
        }

        // POST: api/Rendelt
        [HttpPost]
        public IActionResult Post([FromBody] object value)
        {
            // új rendelés
            return Ok("Új rendelt étel létrehozása");
        }

        // PUT: api/Rendelt/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] object value)
        {
            /// tétel frissítése id alapján
            return Ok($"Rendelt étel frissítése azonosító alapján: {id}");
        }

        // DELETE: api/Rendelt/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            //  rendelt tétel törlése
            return Ok($"Rendelt tétel törlése azonosító alapján: {id}");
        }
    }
}
