﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using backend.Models;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EtelekController : ControllerBase
    {
        private readonly VizsgareworkContext _context;

        public EtelekController(VizsgareworkContext context)
        {
            _context = context;
        }

        // GET: api/Etelek
        [HttpGet]
        public ActionResult<IEnumerable<Etelek>> GetEtelek()
        {
            return _context.Etelek.ToList();
        }

        // GET: api/Etelek/5
        [HttpGet("{id}")]
        public ActionResult<Etelek> GetEtelek(int id)
        {
            var etelek = _context.Etelek.Find(id);

            if (etelek == null)
            {
                return NotFound();
            }

            return etelek;
        }

        // PUT: api/Etelek/5
        [HttpPut("{id}")]
        public IActionResult PutEtelek(Guid id, Etelek etelek)
        {
            if (id != etelek.Id)
            {
                return BadRequest();
            }

            _context.Entry(etelek).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException)
            {
                if (!EtelekExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Etelek
        [HttpPost]
        public ActionResult<Etelek> PostEtelek(Etelek etelek)
        {
            _context.Etelek.Add(etelek);
            _context.SaveChanges();

            return CreatedAtAction("GetEtelek", new { id = etelek.Id }, etelek);
        }

        // DELETE: api/Etelek/5
        [HttpDelete("{id}")]
        public IActionResult DeleteEtelek(int id)
        {
            var etelek = _context.Etelek.Find(id);
            if (etelek == null)
            {
                return NotFound();
            }

            _context.Etelek.Remove(etelek);
            _context.SaveChanges();

            return NoContent();
        }

        private bool EtelekExists(Guid id)
        {
            return _context.Etelek.Any(e => e.Id == id);
        }
    }
}
