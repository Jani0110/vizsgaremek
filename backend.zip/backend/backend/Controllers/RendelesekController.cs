﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using backend.Models;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RendelesekController : ControllerBase
    {
        private readonly VizsgareworkContext _context;

        public RendelesekController(VizsgareworkContext context)
        {
            _context = context;
        }

        // GET: api/Rendelesek
        [HttpGet]
        public ActionResult<IEnumerable<Rendelesek>> GetRendeleseks()
        {
            return _context.Rendelesek.ToList();
        }

        // GET: api/Rendelesek/5
        [HttpGet("{id}")]
        public ActionResult<Rendelesek> GetRendelesek(int id)
        {
            var rendelesek = _context.Rendelesek.Find(id);

            if (rendelesek == null)
            {
                return NotFound();
            }

            return rendelesek;
        }

        // POST: api/Rendelesek
        [HttpPost]
        public ActionResult<Rendelesek> PostRendelesek(Rendelesek rendelesek)
        {
            _context.Rendelesek.Add(rendelesek);
            _context.SaveChanges();

            return CreatedAtAction("GetRendelesek", new { id = rendelesek.Id }, rendelesek);
        }

        // PUT: api/Rendelesek/5
        [HttpPut("{id}")]
        public IActionResult PutRendelesek(int id, Rendelesek rendelesek)
        {
            if (id != rendelesek.Id)
            {
                return BadRequest();
            }

            _context.Entry(rendelesek).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException)
            {
                if (!RendelesekExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Rendelesek/5
        [HttpDelete("{id}")]
        public IActionResult DeleteRendelesek(int id)
        {
            var rendelesek = _context.Rendelesek.Find(id);
            if (rendelesek == null)
            {
                return NotFound();
            }

            _context.Rendelesek.Remove(rendelesek);
            _context.SaveChanges();

            return NoContent();
        }

        private bool RendelesekExists(int id)
        {
            return _context.Rendelesek.Any(e => e.Id == id);
        }
    }
}
