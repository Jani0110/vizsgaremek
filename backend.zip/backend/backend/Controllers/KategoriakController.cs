﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using backend.Models;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KategoriakController : ControllerBase
    {
        private readonly VizsgareworkContext _context;

        public KategoriakController(VizsgareworkContext context)
        {
            _context = context;
        }

        // GET: api/Kategoriak
        [HttpGet]
        public ActionResult<IEnumerable<Kategoriak>> GetKategoriak()
        {
            return _context.Kategoriak.ToList();
        }

        // GET: api/Kategoriak/5
        [HttpGet("{id}")]
        public ActionResult<Kategoriak> GetKategoriak(int id)
        {
            var kategoriak = _context.Kategoriak.Find(id);

            if (kategoriak == null)
            {
                return NotFound();
            }

            return kategoriak;
        }

        // POST: api/Kategoriak
        [HttpPost]
        public ActionResult<Kategoriak> PostKategoriak(Kategoriak kategoriak)
        {
            _context.Kategoriak.Add(kategoriak);
            _context.SaveChanges();

            return CreatedAtAction("GetKategoriak", new { id = kategoriak.Id }, kategoriak);
        }

        // PUT: api/Kategoriak/5
        [HttpPut("{id}")]
        public IActionResult PutKategoriak(int id, Kategoriak kategoriak)
        {
            if (id != kategoriak.Id)
            {
                return BadRequest();
            }

            _context.Entry(kategoriak).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException)
            {
                if (!KategoriakExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Kategoriak/5
        [HttpDelete("{id}")]
        public IActionResult DeleteKategoriak(int id)
        {
            var kategoriak = _context.Kategoriak.Find(id);
            if (kategoriak == null)
            {
                return NotFound();
            }

            _context.Kategoriak.Remove(kategoriak);
            _context.SaveChanges();

            return NoContent();
        }

        private bool KategoriakExists(Guid id)
        {
            return _context.Kategoriak.Any(e => e.Id == id);
        }
    }
}
