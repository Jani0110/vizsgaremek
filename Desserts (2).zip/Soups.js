// src/components/Soups.js
import React from 'react';
import './Soups.css';

const soups = [
  { id: 1, name: 'Chicken Soup', image: '/images/chicken-soup.jpg', description: 'Delicious chicken soup.', price: 5.99 },
  { id: 2, name: 'Tomato Soup', image: '/images/tomato-soup.jpg', description: 'Rich and creamy tomato soup.', price: 4.99 },
  // Add more soups here
];

const Soups = () => {
  return (
    <div className="soups-container">
      {soups.map((soup) => (
        <div key={soup.id} className="soup-card">
          <img src={soup.image} alt={soup.name} className="soup-image" />
          <h3>{soup.name}</h3>
          <p>{soup.description}</p>
          <p className="soup-price">${soup.price.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
};

export default Soups;
