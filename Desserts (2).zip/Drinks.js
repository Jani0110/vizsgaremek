// src/components/Drinks.js
import React from 'react';
import './Drinks.css';

const drinks = [
  { id: 1, name: 'Coca Cola', image: '/images/coca-cola.jpg', description: 'Chilled Coca Cola.', price: 1.99 },
  { id: 2, name: 'Orange Juice', image: '/images/orange-juice.jpg', description: 'Fresh orange juice.', price: 2.99 },
  // Add more drinks here
];

const Drinks = () => {
  return (
    <div className="drinks-container">
      {drinks.map((drink) => (
        <div key={drink.id} className="drink-card">
          <img src={drink.image} alt={drink.name} className="drink-image" />
          <h3>{drink.name}</h3>
          <p>{drink.description}</p>
          <p className="drink-price">${drink.price.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
};

export default Drinks;
