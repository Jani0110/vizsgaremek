// src/components/MeatFood.js
import React from 'react';
import './MeatFood.css';

const meatFoods = [
  { id: 1, name: 'Grilled Chicken', image: '/images/grilled-chicken.jpg', description: 'Juicy grilled chicken.', price: 8.99 },
  { id: 2, name: 'Steak', image: '/images/steak.jpg', description: 'Tender steak.', price: 12.99 },
  // Add more meat foods here
];

const MeatFood = () => {
  return (
    <div className="meat-food-container">
      {meatFoods.map((food) => (
        <div key={food.id} className="meat-food-card">
          <img src={food.image} alt={food.name} className="meat-food-image" />
          <h3>{food.name}</h3>
          <p>{food.description}</p>
          <p className="meat-food-price">${food.price.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
};

export default MeatFood;
