// src/components/Pastas.js
import React from 'react';
import './Pastas.css';

const pastas = [
  { id: 1, name: 'Spaghetti Carbonara', image: '/images/spaghetti-carbonara.jpg', description: 'Classic Italian pasta.', price: 8.99 },
  { id: 2, name: 'Penne Arrabbiata', image: '/images/penne-arrabbiata.jpg', description: 'Spicy penne pasta.', price: 7.99 },
  // Add more pastas here
];

const Pastas = () => {
  return (
    <div className="pastas-container">
      {pastas.map((pasta) => (
        <div key={pasta.id} className="pasta-card">
          <img src={pasta.image} alt={pasta.name} className="pasta-image" />
          <h3>{pasta.name}</h3>
          <p>{pasta.description}</p>
          <p className="pasta-price">${pasta.price.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
};

export default Pastas;
