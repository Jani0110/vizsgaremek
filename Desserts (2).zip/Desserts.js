// src/components/Desserts.js
import React from 'react';
import './Desserts.css';

const desserts = [
  { id: 1, name: 'Chocolate Cake', image: '/images/chocolate-cake.jpg', description: 'Rich chocolate cake.', price: 4.99 },
  { id: 2, name: 'Tiramisu', image: '/images/tiramisu.jpg', description: 'Italian coffee-flavored dessert.', price: 5.49 },
  // Add more desserts here
];

const Desserts = () => {
  return (
    <div className="desserts-container">
      {desserts.map((dessert) => (
        <div key={dessert.id} className="dessert-card">
          <img src={dessert.image} alt={dessert.name} className="dessert-image" />
          <h3>{dessert.name}</h3>
          <p>{dessert.description}</p>
          <p className="dessert-price">${dessert.price.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
};

export default Desserts;
