// src/components/Salads.js
import React from 'react';
import './Salads.css';

const salads = [
  { id: 1, name: 'Caesar Salad', image: '/images/caesar-salad.jpg', description: 'Classic Caesar salad.', price: 6.99 },
  { id: 2, name: 'Greek Salad', image: '/images/greek-salad.jpg', description: 'Fresh Greek salad.', price: 5.99 },
  // Add more salads here
];

const Salads = () => {
  return (
    <div className="salads-container">
      {salads.map((salad) => (
        <div key={salad.id} className="salad-card">
          <img src={salad.image} alt={salad.name} className="salad-image" />
          <h3>{salad.name}</h3>
          <p>{salad.description}</p>
          <p className="salad-price">${salad.price.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
};

export default Salads;
