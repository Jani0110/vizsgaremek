// src/components/RiceFood.js
import React from 'react';
import './RiceFood.css';

const riceFoods = [
  { id: 1, name: 'Fried Rice', image: '/images/fried-rice.jpg', description: 'Tasty fried rice.', price: 6.49 },
  { id: 2, name: 'Rice and Beans', image: '/images/rice-beans.jpg', description: 'Delicious rice and beans.', price: 5.99 },
  // Add more rice foods here
];

const RiceFood = () => {
  return (
    <div className="rice-food-container">
      {riceFoods.map((food) => (
        <div key={food.id} className="rice-food-card">
          <img src={food.image} alt={food.name} className="rice-food-image" />
          <h3>{food.name}</h3>
          <p>{food.description}</p>
          <p className="rice-food-price">${food.price.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
};

export default RiceFood;
