// src/components/Payment.js
import React, { useState } from 'react';
import './Payment.css';

const Payment = () => {
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvc, setCvc] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
   
    console.log('Payment:', { cardNumber, expiryDate, cvc });
  };

  return (
    <div className="payment-container">
      <h2>Payment</h2>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          placeholder="Card Number" 
          value={cardNumber} 
          onChange={(e) => setCardNumber(e.target.value)} 
          required 
        />
        <input 
          type="text" 
          placeholder="Expiry Date (MM/YY)" 
          value={expiryDate} 
          onChange={(e) => setExpiryDate(e.target.value)} 
          required 
        />
        <input 
          type="text" 
          placeholder="CVC" 
          value={cvc} 
          onChange={(e) => setCvc(e.target.value)} 
          required 
        />
        <button type="submit">Fizetés</button>
      </form>
    </div>
  );
};

export default Payment;
