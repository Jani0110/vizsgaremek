﻿using System;
using System.Collections.Generic;

namespace WebshopKarbantarto.Models;

public partial class RendelesAllapot
{
    public int Id { get; set; }

    public string Allapot { get; set; } = null!;

    public virtual ICollection<Rendele> Rendeles { get; set; } = new List<Rendele>();
}
