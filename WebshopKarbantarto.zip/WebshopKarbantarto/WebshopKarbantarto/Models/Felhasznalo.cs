﻿using System;
using System.Collections.Generic;

namespace WebshopKarbantarto.Models;

public partial class Felhasznalo
{
    public Guid Id { get; set; }

    public string Nev { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Jelszo { get; set; } = null!;

    public virtual FelhasznaloCim? FelhasznaloCim { get; set; }

    public virtual Kosar? Kosar { get; set; }

    public virtual ICollection<Rendele> Rendeles { get; set; } = new List<Rendele>();

    public virtual ICollection<TermekErtekele> TermekErtekeles { get; set; } = new List<TermekErtekele>();
}
