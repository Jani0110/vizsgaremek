﻿using System;
using System.Collections.Generic;

namespace WebshopKarbantarto.Models;

public partial class KosarElem
{
    public Guid Id { get; set; }

    public Guid KosarId { get; set; }

    public Guid TermekId { get; set; }

    public int Mennyiseg { get; set; }

    public virtual Kosar Kosar { get; set; } = null!;

    public virtual Termek Termek { get; set; } = null!;
}
