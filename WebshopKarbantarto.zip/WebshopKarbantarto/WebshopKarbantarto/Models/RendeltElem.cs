﻿using System;
using System.Collections.Generic;

namespace WebshopKarbantarto.Models;

public partial class RendeltElem
{
    public Guid Id { get; set; }

    public Guid RendelesId { get; set; }

    public Guid TermekId { get; set; }

    public int TermekDarab { get; set; }

    public virtual Rendele Rendeles { get; set; } = null!;

    public virtual Termek Termek { get; set; } = null!;
}
