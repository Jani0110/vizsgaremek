﻿using System;
using System.Collections.Generic;

namespace WebshopKarbantarto.Models;

public partial class Kategoriak
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public virtual ICollection<Termek> Termeks { get; set; } = new List<Termek>();
}
