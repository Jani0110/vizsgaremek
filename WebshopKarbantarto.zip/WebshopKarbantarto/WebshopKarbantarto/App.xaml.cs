﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WebshopKarbantarto
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static string url = "http://localhost:5259/";
    }

}
