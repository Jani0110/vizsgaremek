﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace WebshopKarbantarto.Dtos
{
    public record ViewModelDto(Guid Id, BitmapImage Image, int CategoryId, string Brand, string Name, double Review,string Description, int Stock, int Price);
    
    //public class MyDataModel
    //{
    //    public Guid Id { get; set; }
    //    public BitmapImage Image { get; set; }
    //    public int CategoryId { get; set; }
    //    public string Brand { get; set; }
    //    public string Name { get; set; }
    //    public string Description { get; set; }
    //    public int Stock { get; set; }
    //    public int Price { get; set; }
    //}
}
