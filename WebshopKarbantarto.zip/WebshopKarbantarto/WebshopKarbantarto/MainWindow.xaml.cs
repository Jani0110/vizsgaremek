﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WebshopKarbantarto
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ShowTermekek(object sender, RoutedEventArgs e)
        {
            Windows.TermekekWindow termekekWindow = new Windows.TermekekWindow();
            termekekWindow.Show();
            this.Close();
        }

        private void ShowRendelesek(object sender, RoutedEventArgs e)
        {
            Windows.RendelesekWindow rendelesekWindow = new Windows.RendelesekWindow();
            rendelesekWindow.Show();
            this.Close();
        }

        private void ShowFelhasznalok(object sender, RoutedEventArgs e)
        {
            Windows.FelhasznalokWindow felhasznalokWindow = new Windows.FelhasznalokWindow();
            felhasznalokWindow.Show();
            this.Close();
        }

        private void Logout(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Biztosan kilép?", "Figyelem!", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                Windows.LoginWindow loginWindow = new Windows.LoginWindow();
                loginWindow.Show();
                this.Close();
            }
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Biztosan bezárja az alkalmazást?", "Figyelem!", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                App.Current.Shutdown();
            }
        }
    }
}