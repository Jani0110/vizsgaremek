﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WebshopKarbantarto.Models;
using WebshopKarbantarto.Dtos;
using System.IO;
using Microsoft.Win32;
using System.ComponentModel;

namespace WebshopKarbantarto.Windows
{
    /// <summary>
    /// Interaction logic for TermekekWindow.xaml
    /// </summary>
    public partial class TermekekWindow : Window
    {
        public List<ViewModelDto> viewProducts = new List<ViewModelDto>();
        public List<ProductDto> rawProducts = new List<ProductDto>();

        private List<ProductDto> GetProducts()
        {
            List<ProductDto> datas = new List<ProductDto>();
            string path = App.url + "Product/getallforwpf";

            WebClient client = new WebClient();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;
            try
            {
                string result = client.DownloadString(path);
                datas = JsonConvert.DeserializeObject<List<ProductDto>>(result);
                return datas;
            }
            catch (Exception ex)
            {
                return datas;
            }
            
        }

        private void UpdateProduct(ProductDto product)
        {
            string path = App.url + "Product/updateProduct";

            WebClient client = new WebClient();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;

            try
            {
                var body = JsonConvert.SerializeObject(product);
                string request = client.UploadString(path,"PUT",body);
                MessageBox.Show("Termék sikeresen módosítva!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DeleteProduct(ProductDto product)
        {
            string path = App.url + "Product/deleteProduct";
            WebClient client = new WebClient();

            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;
            try
            {
                string result = client.UploadString(path, "DELETE", JsonConvert.SerializeObject(product));
                MessageBox.Show("A kiválasztott termék sikeresen törölve!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ReadProducts()
        {
            rawProducts.Clear();
            viewProducts.Clear();
            List<ProductDto> productDtos = GetProducts();
            List<ViewModelDto> viewModelDatas = new List<ViewModelDto>();
            foreach (ProductDto product in productDtos)
            {
                var placeholder = new ViewModelDto(product.Id, Extensions.LoadImage(product.Photo), product.CategoryId, product.Brand, product.Name, product.Review,product.Description, product.Stock, product.Price);
                viewModelDatas.Add(placeholder);
            }
            rawProducts = productDtos;
            viewProducts = viewModelDatas;
            dtgProducts.ItemsSource = viewProducts;

            tb_Id.Text = "";
            tb_Description.Text = "";
            tb_Brand.Text = "";
            tb_Name.Text = "";
            tb_Price.Text = "";
            tb_Stock.Text = "";
        }
        public TermekekWindow()
        {
            InitializeComponent();
            ReadProducts();
        }

        private void dtgProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                tb_Id.Text = (dtgProducts.SelectedItem as ViewModelDto).Id.ToString();
                tb_Brand.Text = (dtgProducts.SelectedItem as ViewModelDto).Brand;
                tb_Name.Text = (dtgProducts.SelectedItem as ViewModelDto).Name;
                tb_Description.Text = (dtgProducts.SelectedItem as ViewModelDto).Description;
                tb_Stock.Text = (dtgProducts.SelectedItem as ViewModelDto).Stock.ToString();
                tb_Price.Text = (dtgProducts.SelectedItem as ViewModelDto).Price.ToString();
            }
            catch { }
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            ProductDto toBeUpdated = rawProducts.FirstOrDefault(x => x.Id.ToString() == tb_Id.Text);
            if (toBeUpdated != null)
            {
                toBeUpdated.Brand = tb_Brand.Text;
                toBeUpdated.Name = tb_Name.Text;
                toBeUpdated.Description = tb_Description.Text;
                toBeUpdated.Stock = int.Parse(tb_Stock.Text);
                toBeUpdated.Price = int.Parse(tb_Price.Text);
                UpdateProduct(toBeUpdated);
                ReadProducts();

            }
            else
            {
                MessageBox.Show("Nincs kiválasztott elem!", "Figyelem!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ModifyImage_Click(object sender, RoutedEventArgs e)
        {
            ProductDto toBeUpdated = rawProducts.FirstOrDefault(x => x.Id.ToString() == tb_Id.Text);
            if (toBeUpdated != null)
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Képfájlok|*.jpg;*.jpeg;*.png";
                if (openFileDialog.ShowDialog() == true)
                {
                    try
                    {
                        byte[] imageBytes = File.ReadAllBytes(openFileDialog.FileName);
                        toBeUpdated.Photo = imageBytes;
                        UpdateProduct(toBeUpdated);
                        ReadProducts();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Hiba történt a kép kiválasztása és átalakítása során: {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Nincs kiválasztott elem!", "Figyelem!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void CreateProduct_Click(object sender, RoutedEventArgs e)
        {
            CreateTermekWindow createTermekWindow = new CreateTermekWindow();
            createTermekWindow.Closing += CreateProductClosing;

            createTermekWindow.Show();

        }

        private void CreateProductClosing(object sender, CancelEventArgs e)
        {
            ReadProducts();
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            var existing = rawProducts.FirstOrDefault(x => x.Id.ToString() == tb_Id.Text);
            if (existing != null)
            {
                DeleteProduct(existing);
                ReadProducts();
            }
            else
            {
                MessageBox.Show("Nincs kiválasztott elem!", "Figyelem!", MessageBoxButton.OK,MessageBoxImage.Warning);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Biztosan visszalép?", "Figyelem!", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }


    }
}
//Scaffold-DbContext "Server=192.168.0.80;Port=3306;Database=mesa_webshop;User Id=root;Password=password;" MySql.Data.EntityFrameworkCore -OutputDir Models -f