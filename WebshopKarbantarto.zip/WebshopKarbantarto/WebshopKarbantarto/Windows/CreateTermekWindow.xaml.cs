﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using WebshopKarbantarto.Dtos;
using static Org.BouncyCastle.Asn1.Cmp.Challenge;

namespace WebshopKarbantarto.Windows
{
    /// <summary>
    /// Interaction logic for CreateTermekWindow.xaml
    /// </summary>
    public partial class CreateTermekWindow : Window
    {
        public static byte[] productImage = null;
        private void CreateProduct(CreateProductDto product)
        {
            string path = App.url + "Product/uploadProduct";

            WebClient client = new WebClient();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;

            try
            {
                string result = client.UploadString(path, "POST", JsonConvert.SerializeObject(product));
                MessageBox.Show("Termék sikeresen hozzáadva");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public CreateTermekWindow()
        {
            InitializeComponent();
        }

        private void UploadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Képfájlok|*.jpg;*.jpeg;*.png";
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    byte[] imageBytes = File.ReadAllBytes(openFileDialog.FileName);
                    productImage = imageBytes;
                    ProductImage.Source = Extensions.LoadImage(imageBytes);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Hiba történt a kép kiválasztása és átalakítása során: {ex.Message}");
                }
            }
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            CreateProductDto newProduct = new CreateProductDto(
                productImage,
                int.Parse(tb_CategoryId.Text),
                tb_Brand.Text,
                tb_Name.Text,
                tb_Description.Text,
                int.Parse(tb_Stock.Text),
                int.Parse(tb_Price.Text)
                );

            CreateProduct(newProduct);
            this.Close();
            
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Biztosan kilép?\nAz idáig beírt adatok elvesznek!", "Figyelem!", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }

        private void PopupImage_Click(object sender, RoutedEventArgs e)
        {
            imagePopup.IsOpen = true;
        }

        private void ClosePopup_Click(object sender, RoutedEventArgs e)
        {
            imagePopup.IsOpen = false;
        }
    }
}
