﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WebshopKarbantarto.Dtos;

namespace WebshopKarbantarto.Windows
{
    public partial class FelhasznalokWindow : Window
    {
        public List<UserDto> users = new List<UserDto>();

        private List<UserDto> GetUsers()
        {
            List<UserDto> datas = new List<UserDto>();
            string path = App.url + "User/getAllForWpf";

            WebClient client = new WebClient();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;
            try
            {
                string result = client.DownloadString(path);
                datas = JsonConvert.DeserializeObject<List<UserDto>>(result);
                return datas;
            }
            catch (Exception ex)
            {
                return datas;
            }

        }
        private void DeleteUser(UserDto userDto)
        {
            string path = App.url + "User/DeleteFromWpf";
            WebClient client = new WebClient();

            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;
            try
            {
                string result = client.UploadString(path, "DELETE", JsonConvert.SerializeObject(userDto));
                MessageBox.Show("A kiválasztott felhasználó sikeresen törölve!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Refresh()
        {
            users.Clear();
            users = GetUsers();
            dtgUsers.ItemsSource = users;

            tb_Id.Text = "";
            tb_Email.Text = "";
            tb_Name.Text = "";
            tb_Password.Text = "";
        }
        public FelhasznalokWindow()
        {
            InitializeComponent();
            Refresh();
        }

        private void dtgUsers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                tb_Id.Text = (dtgUsers.SelectedItem as UserDto).Id.ToString();
                tb_Name.Text = (dtgUsers.SelectedItem as UserDto).Name.ToString();
                tb_Email.Text = (dtgUsers.SelectedItem as UserDto).Email.ToString();
                tb_Password.Text = (dtgUsers.SelectedItem as UserDto).Password.ToString();
            }
            catch { }
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Biztosan visszalép?", "Figyelem!", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }

        private void DeleteUser_Click(object sender, RoutedEventArgs e)
        {
            if (tb_Id.Text != "")
            {
                UserDto user = new UserDto(Guid.Parse(tb_Id.Text), tb_Name.Text, tb_Email.Text, tb_Password.Text);
                DeleteUser(user);
                Refresh();
            }
            else
            {
                MessageBox.Show("Nincs kiválasztott felhasználó!","Figyelem!",MessageBoxButton.OK, MessageBoxImage.Warning);    
            }
        }
    }
}
