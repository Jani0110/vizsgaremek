﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WebshopKarbantarto.Dtos;

namespace WebshopKarbantarto.Windows
{
    /// <summary>
    /// Interaction logic for RendelesekWindow.xaml
    /// </summary>
    public partial class RendelesekWindow : Window
    {
        List<OrderDto> orders = new List<OrderDto>();
        private List<OrderDto> GetAllOrder()
        {
            List<OrderDto> datas = new List<OrderDto>();
            string path = App.url + "Order/getAllRendeles";

            WebClient client = new WebClient();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;
            try
            {
                string result = client.DownloadString(path);
                datas = JsonConvert.DeserializeObject<List<OrderDto>>(result);
                return datas;
            }
            catch (Exception ex)
            {
                return datas;
            }

        }
        private void UpdateOrder(UpdateOrderDto updateOrderDto)
        {
            string path = App.url + "Order/updateRendeles";

            WebClient client = new WebClient();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;

            try
            {
                var body = JsonConvert.SerializeObject(updateOrderDto);
                string request = client.UploadString(path, "PUT", body);
                MessageBox.Show("Rendelés sikeresen frissítve!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Refresh()
        {
            searched.Clear();
            products.Clear();
            orders.Clear();
            orders = GetAllOrder();
            dtgOrders.ItemsSource = orders;

            tb_Id.Text = "";
            tb_Date.Text = "";
            tb_Address.Text = "";
            tb_Price.Text = "";
            tb_UserId.Text = "";
            tb_SearchId.Text = "";
        }
        public RendelesekWindow()
        {
            InitializeComponent();
            Refresh();
        }

        private void dtgOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                tb_Id.Text = (dtgOrders.SelectedItem as OrderDto).Id.ToString();
                tb_UserId.Text = (dtgOrders.SelectedItem as OrderDto).UserId.ToString();
                tb_Address.Text = (dtgOrders.SelectedItem as OrderDto).Address;
                tb_Date.Text = (dtgOrders.SelectedItem as OrderDto).OrderDate;
                tb_Price.Text = (dtgOrders.SelectedItem as OrderDto).Cost.ToString() + "  Ft";
                cb_OrderState.Text = (dtgOrders.SelectedItem as OrderDto).OrderState;
            }
            catch { }
        }

        public static List<ViewOrderedItemsDto> products = new List<ViewOrderedItemsDto>();
        private void ViewOrderedItems_Click(object sender, RoutedEventArgs e)
        {
            products.Clear();
         
            OrderDto order = orders.FirstOrDefault(x => x.Id == Guid.Parse(tb_Id.Text));
            if (order != null)
            {
                foreach (var prod in order.OrderedItems)
                {
                    var placeholder = new ViewOrderedItemsDto(prod.Name, Extensions.LoadImage(prod.Photo), prod.Cost, prod.Quantity);
                    products.Add(placeholder);
                }
            }
            else
            {
                MessageBox.Show("Nincs kiválasztott rendelés!", "Figyelem!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            dtgProducts.ItemsSource = products;
            productsPopup.IsOpen = true;
        }

        private void ClosePopup_Click(object sender, RoutedEventArgs e)
        {
            productsPopup.IsOpen = false;
            Refresh();
        }

        private void SaveOrderState_Click(object sender, RoutedEventArgs e)
        {
            Guid orderId = Guid.Parse(tb_Id.Text);
            int orderStatus = cb_OrderState.SelectedIndex + 1;

            UpdateOrderDto updateOrderDto = new UpdateOrderDto(orderId, orderStatus);
            UpdateOrder(updateOrderDto);
            Refresh();
        }

        List<OrderDto> searched = new List<OrderDto>();
        private void SearchById_Click(object sender, RoutedEventArgs e)
        {
            Guid searchId;
            if (Guid.TryParse(tb_SearchId.Text, out searchId))
            {
                foreach (var item in orders)
                {
                    if (item.Id == searchId)
                    {
                        searched.Add(item);
                    }
                }
                dtgOrders.ItemsSource = searched;
                if (searched == null)
                {
                    MessageBox.Show("Nem található a keresett rendelés", "Figyelem!", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Érvénytelen id", "Figyelem!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            Refresh();
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Biztosan visszalép?", "Figyelem!", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }
    }
}
